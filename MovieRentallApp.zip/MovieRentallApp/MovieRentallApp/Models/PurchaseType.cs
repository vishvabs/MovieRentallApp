﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieRentallApp.Models
{
    public class PurchaseType
    {
        public string TypeName { get; set; }
        public bool Val { get; set; }
    }
}
